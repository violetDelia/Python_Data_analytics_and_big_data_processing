import redis

BUSINESS_URL_REDIS_KEY = "business:starturls"
PRODUCT_URL_REDIS_KEY = "product:starturls"
pool = redis.ConnectionPool(host="127.0.0.1", password="")  # 实现一个连接池
redis_obj = redis.Redis(connection_pool=pool)
