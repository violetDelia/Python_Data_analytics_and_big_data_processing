# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from nuomi.config import redis_obj, BUSINESS_URL_REDIS_KEY
from nuomi.items import ProductDetailItem, BusinessDetailItem, BusinessItem


class InsertStartUrls(object):
    @staticmethod
    def process_item(item):
        if item is not None:
            redis_obj.lpush(BUSINESS_URL_REDIS_KEY, item["url"])


class BusinessDetail(object):
    @staticmethod
    def process_item(item):
        if item is not None:
            with open("business_detail.txt", "a") as f:
                f.write(BusinessDetail.get_str(item) + "\n")

    @staticmethod
    def get_str(item):
        return "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}".format(
            item["shopid"], item["name"], item["score"], item["percus"], item["address"],
            item["good"], item["bad"], item["medium"], item["total"], item["hasproduct"]
        )


class ProductDetail(object):
    @staticmethod
    def process_item(item):
        if item is not None:
            with open("product_detail.txt", "a") as f:
                f.write(ProductDetail.get_str(item) + "\n")

    @staticmethod
    def get_str(item):
        return "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}".format(
            item["shopid"], item["productid"], item["name"], item["price"], item["sold"], item["score"],
            item["good"], item["bad"], item["medium"], item["total"]
        )


class NuomiPipeline(object):
    def process_item(self, item, spider):
        if isinstance(item, BusinessItem):
            InsertStartUrls.process_item(item)
        elif isinstance(item, BusinessDetailItem):
            BusinessDetail.process_item(item)
        elif isinstance(item, ProductDetailItem):
            ProductDetail.process_item(item)
