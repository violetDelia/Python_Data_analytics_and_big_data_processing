# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy_redis.spiders import RedisCrawlSpider

from nuomi.config import BUSINESS_URL_REDIS_KEY
from nuomi.items import BusinessDetailItem, ProductDetailItem


class BusinessdetailSpider(RedisCrawlSpider):
    name = 'businessdetail'
    allowed_domains = ['bj.nuomi.com/326']
    redis_key = BUSINESS_URL_REDIS_KEY

    def get_item(self):
        # 获取商家详情对象所有字段
        item = BusinessDetailItem()
        for i in item.fields:
            item[i] = ""
        return item

    def parse_product_detail(self, response):
        # 获取商品详情对象所有字段
        detail_item = ProductDetailItem()
        for i in detail_item.fields:
            detail_item[i] = ""

        # 解析商品信息----开始
        detail_item["shopid"] = response.meta["shopid"]
        detail_item["productid"] = response.xpath("//div[@class='p-item-info']").attrib["mon"].split("=")[1]
        detail_item["name"] = response.xpath("//div[@class='p-item-info']/div/h2/text()").extract_first()
        price = response.xpath("//div[@class='p-item-info']/div/div[@class='item-title']/span/text()").extract_first()
        try:
            detail_item["price"] = re.findall(r"\d+\.?\d*", price)[0]
        except Exception as e:
            detail_item["price"] = ""

        detail_item["sold"] = response.xpath("//li[@class='item-bought']/div/div/div/span/text()").extract_first()
        if len(response.xpath(
                "//li[@id='j-ugc-grade']/div[@class='sl-wrap']/div[@class='sl-wrap-cnt']/div[@class='no-comment']")) > 0:
            detail_item["score"] = ""
        else:
            detail_item["score"] = response.xpath(
                "//li[@id='j-ugc-grade']/div[@class='ugc-star clearfix']/div[@class='us-grade']/text()").extract_first()

        detail_item["total"] = response.xpath(
            "//div[@mon='area=comment&element_type=filter']/ul[@id='j-level-filter']/li[1]/a/span/span/text()").extract_first()

        detail_item["good"] = response.xpath(
            "//div[@mon='area=comment&element_type=filter']/ul[@id='j-level-filter']/li[2]/a/span/span/text()").extract_first()

        detail_item["bad"] = response.xpath(
            "//div[@mon='area=comment&element_type=filter']/ul[@id='j-level-filter']/li[4]/a/span/span/text()").extract_first()

        detail_item["medium"] = response.xpath(
            "//div[@mon='area=comment&element_type=filter']/ul[@id='j-level-filter']/li[3]/a/span/span/text()").extract_first()

        # 解析商品信息----结束
        yield detail_item

    def parse(self, response):

        item = self.get_item()

        try:
            # 解析商家信息----开始
            item["shopid"] = response.url.split("/")[-1]
            item["name"] = response.xpath("//div[@class='shop-box']/h2/text()").extract_first().strip()
            item["score"] = response.xpath(
                "//div[@class='shop-box']/p[@class='shop-info']/span[@class='score']/text()").extract_first()
            item["score"] = "" if item["score"] is None else item["score"]

            item["percus"] = response.xpath(
                "//div[@class='shop-box']/p[@class='shop-info']/span[@class='price']/strong/text()").extract_first()[1:]
            item["percus"] = "" if item["percus"] is None else item["percus"]

            item["address"] = response.xpath(
                "//ul[@class='shop-list']/li[1]/p[@class='bd detail-shop-address']/span/text()").extract_first().strip()
            item["address"] = "" if item["address"] is None else item["address"]

            item["total"] = response.xpath(
                "//div[@mon='area=comment&element_type=filter']/ul[@id='j-level-filter']/li[1]/a/span/span/text()").extract_first()
            item["total"] = "" if item["total"] is None else item["total"]

            item["good"] = response.xpath(
                "//div[@mon='area=comment&element_type=filter']/ul[@id='j-level-filter']/li[2]/a/span/span/text()").extract_first()
            item["good"] = "" if item["good"] is None else item["good"]

            item["bad"] = response.xpath(
                "//div[@mon='area=comment&element_type=filter']/ul[@id='j-level-filter']/li[4]/a/span/span/text()").extract_first()
            item["bad"] = "" if item["bad"] is None else item["bad"]

            item["medium"] = response.xpath(
                "//div[@mon='area=comment&element_type=filter']/ul[@id='j-level-filter']/li[3]/a/span/span/text()").extract_first()
            item["medium"] = "" if item["medium"] is None else item["medium"]

            item["hasproduct"] = len(response.xpath("//div[@class='shop-current']/div[@class='col-wrap']")) > 0
            item["hasproduct"] = "" if item["hasproduct"] is None else item["hasproduct"]

            # 把获取到的新链接放入redis
            div_col_wrap_list = response.xpath("//div[@class='shop-current']/div[@class='col-wrap']")
            # 解析商家信息----结束
            yield item
            for div in div_col_wrap_list:
                product_link = "https:" + div.xpath(
                    "//div[@class='shop-current']/div[@class='col-wrap']/div[@class='n-item col col-1']/a").attrib[
                    "href"]

                # 开启新的请求爬取商品信息
                yield scrapy.Request(url=product_link,
                                     meta={"shopid": item["shopid"]},
                                     callback=self.parse_product_detail,
                                     dont_filter=True)

        except Exception as e:
            pass
