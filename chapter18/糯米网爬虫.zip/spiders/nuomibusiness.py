# -*- coding: utf-8 -*-
import scrapy

from nuomi.items import BusinessItem


class NuomibusinessSpider(scrapy.Spider):
    name = 'nuomibusiness'
    allowed_domains = ['bj.nuomi.com/326']

    start_urls = ['http://bj.nuomi.com/326/']

    def __init__(self):
        total_item = 1250
        page_count = int(total_item / 25) + 1
        for i in range(2, page_count):
            self.start_urls.append("https://bj.nuomi.com/326-page{0}?#j-sort-bar".format(i))

    def parse(self, response):
        li_list = response.xpath("//ul[@class='shop-infoo-list-ul']/li")
        for li in li_list:
            business_url = li.xpath("./a[@href][1]")[0].attrib["href"][2:]
            item = BusinessItem()
            item["url"] = "https://" + business_url
            yield item
