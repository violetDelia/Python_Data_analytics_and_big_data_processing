# -*- coding: UTF-8 -*-
"""
查看糯米北京站主页，每页显示25个商家，因此可以使用
总条数/25得到总页数。本脚本就是构造所有的商家页面链接
并放入redis
"""
import redis

pool = redis.ConnectionPool(host="127.0.0.1", password='')
r = redis.Redis(connection_pool=pool)
r.set("nuomi:start_urls", "https://bj.nuomi.com/326")
print(r.get("nuomi:start_urls").decode('utf8'))
