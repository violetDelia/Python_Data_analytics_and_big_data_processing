from selenium import webdriver
from scrapy.http import HtmlResponse
from logging import getLogger
from selenium.webdriver.chrome.options import Options

import random
import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait


class SeleniumDownloadMiddleware(object):
    def __init__(self, delay, user_agent_list, ip_list):
        self.logger = getLogger(__name__)
        self.delay = delay
        options = Options()
        options.add_argument("--headless")
        options.add_argument("--no-sandbox")
        # 禁用gpu
        options.add_argument("--disable-gpu")
        # 隐藏滚动条
        options.add_argument("--hide-scrollbars")
        # 禁止加载图片
        options.add_argument("--blink-settings=imagesEnabled=false")
        options.add_argument('--user-agent={0}'.format(random.choice(user_agent_list)))
        # options.add_argument('--proxy-server=http://{0}'.format(random.choice(ip_list)))
        # 配置谷歌无头浏览器
        self.browser = webdriver.Chrome(executable_path=r"D:\ProgramData\Anaconda3-pkgs\chromedriver.exe",
                                        options=options)

    def __del__(self):
        self.browser.close()

    def process_request(self, request, spider):
        delay = random.randint(7, self.delay)
        self.logger.debug("随机延迟时间:{0}s".format(delay))
        time.sleep(delay)
        if "ajax-list" in request.url:
            return None
        else:
            try:
                self.browser.get(request.url)
                WebDriverWait(self.browser, 15).until(lambda x: x.find_element_by_class_name("poi-card"))
            except Exception as e:
                pass
            return HtmlResponse(url=request.url, body=self.browser.page_source,
                                request=request, encoding="utf-8", status=200)

    def process_response(self, request, response, spider):
        return response

    @classmethod
    def from_crawler(cls, crawler):

        ip_list=[]
        return cls(delay=10, user_agent_list=crawler.settings.get("USER_AGENT_LIST"), ip_list=ip_list)
