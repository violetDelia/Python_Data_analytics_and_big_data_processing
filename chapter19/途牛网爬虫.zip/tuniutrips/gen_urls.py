import redis
import time

pool = redis.ConnectionPool(host="127.0.0.1", password='')
r = redis.Redis(connection_pool=pool)
page_count = 1197
print("正在生成链接...")
for i in range(1, page_count):
    timestamp = int(round(time.time() * 1000))
    url = "http://trips.tuniu.com/travels/index/ajax-list?sortType=1&page={0}&limit=10&_={1}".format(i, timestamp)
    print(url)
    r.rpush("tuniu:start_urls", url)

print("执行完毕！")
