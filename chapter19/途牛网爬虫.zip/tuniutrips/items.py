# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class TuniutripsItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass


class TourismItem(scrapy.Item):
    url = scrapy.Field()


class TravelsItem(scrapy.Item):
    # 游记文章ID
    id = scrapy.Field()
    # 游记标题名称
    name = scrapy.Field()
    # 游记作者ID
    authorId = scrapy.Field()
    # 浏览次数
    viewCount = scrapy.Field()
    # 喜欢次数
    likeCount = scrapy.Field()
    # 评论次数
    commentCount = scrapy.Field()
    # 发布时间
    publishTime = scrapy.Field()
    picUrl = scrapy.Field()
    # 作者昵称
    authorName = scrapy.Field()
    authorHeadImg = scrapy.Field()
    authorIndentity = scrapy.Field()
    hasLike = scrapy.Field()


class TravelsDetailItem(scrapy.Item):
    id = scrapy.Field()
    taglist = scrapy.Field()
    destination = scrapy.Field()
    price = scrapy.Field()
