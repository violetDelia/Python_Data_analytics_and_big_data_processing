# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql
import redis

from tuniutrips.items import TravelsItem, TravelsDetailItem


class Travels(object):
    @staticmethod
    def insert_db(item, pipeline_obj):
        sql = '''
                INSERT   travels(id,name,authorId,viewCount,likeCount,
                commentCount,publishTime,picUrl,authorName,
                authorHeadImg,authorIndentity,hasLike)
                VALUES('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')
                '''.format(item["id"], item["name"], item["authorId"], item["viewCount"],
                           item["likeCount"], item["commentCount"], item["publishTime"], item["picUrl"],
                           item["authorName"], item["authorHeadImg"], item["authorIndentity"], item["hasLike"])
        pipeline_obj.mysql_conn.query(sql)
        pipeline_obj.mysql_conn.commit()

    @staticmethod
    def insert_redis(item, pipeline_obj):
        detail_url = "http://www.tuniu.com/trips/" + str(item["id"])
        pipeline_obj.redis_obj.rpush("tuniu:detail_urls", detail_url)


class TravelsDetail(object):
    @staticmethod
    def insert_db(item, pipeline_obj):
        sql = '''
                INSERT travels_detail(id,taglist,destination,price)VALUES('{}','{}','{}','{}')
                '''.format(item["id"], item["taglist"], item["destination"], item["price"])
        print(sql)
        pipeline_obj.mysql_conn.query(sql)
        pipeline_obj.mysql_conn.commit()


class TuniutripsPipeline(object):
    def open_spider(self, spider):
        self.mysql_conn = pymysql.connect(host="localhost",
                                          port=3306,
                                          user="root",
                                          passwd="root",
                                          db="test")
        pool = redis.ConnectionPool(host="127.0.0.1", password='')
        self.redis_obj = redis.Redis(connection_pool=pool)

    def process_item(self, item, spider):
        if isinstance(item, TravelsItem):
            Travels.insert_db(item, self)
            Travels.insert_redis(item, self)
        elif isinstance(item, TravelsDetailItem):
            TravelsDetail.insert_db(item, self)

    def close_spider(self, spider):
        self.mysql_conn.close()
