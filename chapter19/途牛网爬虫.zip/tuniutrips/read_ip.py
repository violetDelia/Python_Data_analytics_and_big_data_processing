file = r"D:\workspace\PycharmProjects\scrapys\spyder\tuniutrips\tuniutrips\ip.txt"
f = open(file, "r")
for i in f.split("n"):
    print( f.split("n"))
