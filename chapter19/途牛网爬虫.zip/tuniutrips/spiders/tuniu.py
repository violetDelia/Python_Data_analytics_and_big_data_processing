# -*- coding: utf-8 -*-
import json

from scrapy_redis.spiders import RedisCrawlSpider

from tuniutrips.items import TravelsItem


class TuniuSpider(RedisCrawlSpider):
    name = "tuniu"
    allowed_domains = ["trips.tuniu.com"]
    redis_key = "tuniu:start_urls"

    def parse(self, response):
        # 将获取的数据转换为json对象
        data = json.loads(response.text)
        for row in data["data"]["rows"]:
            item = TravelsItem()
            # 通过反射的方式给item赋值
            for k in row.keys():
                if k in item.fields:
                    item[k] = row[k]

            yield item

