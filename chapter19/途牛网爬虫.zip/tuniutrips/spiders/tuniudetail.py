# -*- coding: utf-8 -*-
import scrapy
from scrapy_redis.spiders import RedisCrawlSpider

from tuniutrips.items import TravelsDetailItem


class TuniudetailSpider(RedisCrawlSpider):
    name = "detail_urls"
    allowed_domains = ["trips.tuniu.com"]
    redis_key = "tuniu:detail_urls"

    def parse(self, response):
        tag_list = response.xpath("//div[@class='tag-list clearfix']/div[@class='tag-item']/text()")
        tags = []
        for i in tag_list:
            tags.append(i.root)

        item = TravelsDetailItem()
        item["taglist"] = ",".join(tags)
        item["destination"] = response.xpath("//div[@class='poi-title']/text()").extract_first()
        item["price"] = response.xpath(
            "//div[@class='prd-info']/span[@class='price']/span[@class='big']/text()").extract_first()
        item["id"] = response.url.split("/")[-1]
        return item
