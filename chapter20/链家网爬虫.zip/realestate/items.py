# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class RealestateItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass


class LianJiaItem(scrapy.Item):
    url = scrapy.Field()


class LianJiaDetailItem(scrapy.Item):
    # 链家房产编号
    lianjiabianhao = scrapy.Field()
    # 总价
    total = scrapy.Field()
    # 平米价
    unitprice = scrapy.Field()
    # 小区名称
    compoundname = scrapy.Field()
    # 所在区域
    zone = scrapy.Field()

    # 户型
    roomtype = scrapy.Field()
    # 建筑面积
    builtuparea = scrapy.Field()
    # 房屋结构
    structure = scrapy.Field()
    # 套内面积
    usablearea = scrapy.Field()

    # 挂牌时间
    listingdate = scrapy.Field()
    # 上次交易时间
    lasttradedate = scrapy.Field()

    # 房源特色
    tags = scrapy.Field()

    # 最近7天带看次数
    latest7 = scrapy.Field()
