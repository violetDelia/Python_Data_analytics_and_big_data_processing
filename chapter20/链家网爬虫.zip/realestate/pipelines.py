# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymongo
import redis

from realestate.items import LianJiaItem, LianJiaDetailItem


class LianJia(object):
    @staticmethod
    def insert_redis(pipeline, item):
        pipeline.redis_obj.rpush("lianjia:detail_urls", item["url"])


class LianJiaDetail(object):
    @staticmethod
    def insert_mango(pipeline, item):
        # 将实体转为字典
        document = dict(item)
        # 将字典存入MangoDB
        pipeline.coll.insert(document)


class RealestatePipeline(object):

    def __init__(self):
        # 设置mongodb数据库连接
        client = pymongo.MongoClient(host="localhost", port=27017)
        self.db = client["test"]
        self.coll = self.db["lianjiadetail"]

        # 设置redis数据库连接
        pool = redis.ConnectionPool(host="127.0.0.1", password='')
        self.redis_obj = redis.Redis(connection_pool=pool)

    def process_item(self, item, spider):
        if isinstance(item, LianJiaItem):
            LianJia.insert_redis(self, item)
        elif isinstance(item, LianJiaDetailItem):
            LianJiaDetail.insert_mango(self, item)
