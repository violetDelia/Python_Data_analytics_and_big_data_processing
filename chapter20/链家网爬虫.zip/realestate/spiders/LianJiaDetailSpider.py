# -*- coding: utf-8 -*-
from scrapy_redis.spiders import RedisCrawlSpider
from realestate.items import LianJiaDetailItem

class LianJiaSpider(RedisCrawlSpider):
    name = "lianjiadetail"
    allowed_domains = ["bj.lianjia.com"]
    redis_key = "lianjia:detail_urls"

    def parse(self, response):
        item = LianJiaDetailItem()
        item["lianjiabianhao"] = response.xpath(
            "//div[@class='overview']/div[@class='content']/div[@class='aroundInfo']/div[@class='houseRecord']/span[@class='info']/text()").extract_first()
        item["total"] = response.xpath(
            "//div[@class='overview']/div[@class='content']/div[@class='price ']/span[@class='total']/text()").extract_first()
        item["unitprice"] = response.xpath(
            "//div[@class='overview']/div[@class='content']/div[@class='price ']/div[@class='text']/div[@class='unitPrice']/span[@class='unitPriceValue']/text()").extract_first()
        item["compoundname"] = response.xpath(
            "//div[@class='overview']/div[@class='content']/div[@class='aroundInfo']/div[@class='communityName']/a[@class='info ']/text()").extract_first()
        item["zone"] = response.xpath(
            "//div[@class='overview']/div[@class='content']/div[@class='aroundInfo']/div[@class='areaName']/span[@class='info']/a[1]/text()").extract_first()

        li_list = response.xpath(
            "//div[@class='introContent']/div[@class='base']/div[@class='content']/ul/li/text()")
        item["roomtype"] = li_list[0].root
        item["builtuparea"] = li_list[2].root
        item["structure"] = li_list[3].root
        item["usablearea"] = li_list[4].root

        span_list = response.xpath(
            "//div[@class='introContent']/div[@class='transaction']/div[@class='content']/ul/li/span/text()")
        item["listingdate"] = span_list[1].root
        item["lasttradedate"] = span_list[5].root

        a_list = response.xpath(
            "//div[@class='introContent showbasemore']/div[@class='tags clear']/div[@class='content']/a/text()")
        tag_list = []
        for a in a_list:
            tag_list.append(a.root)

        item["tags"] = ",".join(tag_list)

        item["latest7"] = response.xpath(
            "//div[@id='record']/div[@class='panel']/div[@class='count']/text()").extract_first()
        yield item
