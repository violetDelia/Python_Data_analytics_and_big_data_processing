from pyspark.sql import SparkSession

spark = SparkSession \
    .builder \
    .appName("linajia") \
    .config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.lianjiadetail") \
    .config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.lianjiadetail") \
    .getOrCreate()

# 读取lianjiadetail表数据并创建数据帧
df = spark.read.format("com.mongodb.spark.sql.DefaultSource").load()
# 查找离地铁近的房源，以及总价、平米单价
metro_house = df.filter(df.tags.like("%地铁%")).select(df["compoundname"], df["zone"], df["total"], df["unitprice"])
metro_house.show()
